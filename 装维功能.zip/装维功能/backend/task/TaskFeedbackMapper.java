package com.zhiwei.task;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaskFeedbackMapper extends BaseMapper<TaskFeedback> {
}
